﻿namespace coffee_cashier
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            dataGridView1 = new DataGridView();
            showUsername = new DataGridViewTextBoxColumn();
            showPassword = new DataGridViewTextBoxColumn();
            showAccessLevel = new DataGridViewTextBoxColumn();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            inputUsername = new Label();
            inputPassword = new Label();
            label4 = new Label();
            inputAccess = new DomainUpDown();
            addUser = new Button();
            deleteUser = new Button();
            clearButton = new Button();
            label2 = new Label();
            saveUsers = new Button();
            saveFileDialog1 = new SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(355, 74);
            label1.Name = "label1";
            label1.Size = new Size(110, 15);
            label1.TabIndex = 0;
            label1.Text = "MANAJEMEN USER";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { showUsername, showPassword, showAccessLevel });
            dataGridView1.Location = new Point(248, 101);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(334, 150);
            dataGridView1.TabIndex = 1;
            // 
            // showUsername
            // 
            showUsername.HeaderText = "Username";
            showUsername.Name = "showUsername";
            // 
            // showPassword
            // 
            showPassword.HeaderText = "Password";
            showPassword.Name = "showPassword";
            // 
            // showAccessLevel
            // 
            showAccessLevel.HeaderText = "Access Level";
            showAccessLevel.Name = "showAccessLevel";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(248, 290);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(365, 290);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 3;
            // 
            // inputUsername
            // 
            inputUsername.AutoSize = true;
            inputUsername.Location = new Point(248, 272);
            inputUsername.Name = "inputUsername";
            inputUsername.Size = new Size(60, 15);
            inputUsername.TabIndex = 5;
            inputUsername.Text = "Username";
            // 
            // inputPassword
            // 
            inputPassword.AutoSize = true;
            inputPassword.Location = new Point(365, 272);
            inputPassword.Name = "inputPassword";
            inputPassword.Size = new Size(57, 15);
            inputPassword.TabIndex = 6;
            inputPassword.Text = "Password";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(482, 272);
            label4.Name = "label4";
            label4.Size = new Size(73, 15);
            label4.TabIndex = 7;
            label4.Text = "Access Level";
            // 
            // inputAccess
            // 
            inputAccess.Items.Add("Admin");
            inputAccess.Items.Add("Manager");
            inputAccess.Items.Add("Kasir");
            inputAccess.Location = new Point(482, 291);
            inputAccess.Name = "inputAccess";
            inputAccess.Size = new Size(100, 23);
            inputAccess.TabIndex = 8;
            // 
            // addUser
            // 
            addUser.Location = new Point(668, 322);
            addUser.Name = "addUser";
            addUser.Size = new Size(81, 23);
            addUser.TabIndex = 9;
            addUser.Text = "Tambahkan";
            addUser.UseVisualStyleBackColor = true;
            addUser.Click += button1_Click;
            // 
            // deleteUser
            // 
            deleteUser.Location = new Point(668, 376);
            deleteUser.Name = "deleteUser";
            deleteUser.Size = new Size(81, 23);
            deleteUser.TabIndex = 10;
            deleteUser.Text = "Hapus";
            deleteUser.UseVisualStyleBackColor = true;
            deleteUser.Click += deleteUser_Click;
            // 
            // clearButton
            // 
            clearButton.Location = new Point(668, 415);
            clearButton.Name = "clearButton";
            clearButton.Size = new Size(81, 23);
            clearButton.TabIndex = 11;
            clearButton.Text = "Clear ";
            clearButton.UseVisualStyleBackColor = true;
            clearButton.Click += clearButton_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(534, 358);
            label2.Name = "label2";
            label2.Size = new Size(215, 15);
            label2.TabIndex = 12;
            label2.Text = "Sebelum hapus user, wajib clear dahulu";
            // 
            // saveUsers
            // 
            saveUsers.Location = new Point(33, 394);
            saveUsers.Name = "saveUsers";
            saveUsers.Size = new Size(75, 23);
            saveUsers.TabIndex = 13;
            saveUsers.Text = "Simpan Users";
            saveUsers.UseVisualStyleBackColor = true;
            saveUsers.Click += saveUsers_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(saveUsers);
            Controls.Add(label2);
            Controls.Add(clearButton);
            Controls.Add(deleteUser);
            Controls.Add(addUser);
            Controls.Add(inputAccess);
            Controls.Add(label4);
            Controls.Add(inputPassword);
            Controls.Add(inputUsername);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(dataGridView1);
            Controls.Add(label1);
            Name = "Form3";
            Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn showUsername;
        private DataGridViewTextBoxColumn showPassword;
        private DataGridViewTextBoxColumn showAccessLevel;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label inputUsername;
        private Label inputPassword;
        private Label label4;
        private DomainUpDown inputAccess;
        private Button addUser;
        private Button deleteUser;
        private Button clearButton;
        private Label label2;
        private Button saveUsers;
        private SaveFileDialog saveFileDialog1;
    }
}