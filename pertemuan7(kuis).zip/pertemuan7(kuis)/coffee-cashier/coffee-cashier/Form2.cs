﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace coffee_cashier
{
    public partial class Form2 : Form
    {
        public class User
        {
            public String Username { get; set; }
            public string Password { get; set; }
            public string AccessLevel { get; set; }
        }

        private List<User> userList = new List<User>();

        public Form2()
        {
            User user1 = new User { Username = "Ihsanfati", Password = "ihsan123", AccessLevel = "Admin" };
            User user2 = new User { Username = "Rayhanhamdany", Password = "rayhan123", AccessLevel = "Manager" };
            User user3 = new User { Username = "Faizalgina", Password = "gina123", AccessLevel = "Kasir" };

            userList.Add(user1);
            userList.Add(user2);
            userList.Add(user3);

            InitializeComponent();
        }
        
        private void login_Click(object sender, EventArgs e)
        {
            string newUsername = username.Text;
            string newPassword = password.Text;

            // Mencari pengguna dengan username dan password yang cocok
            User user = userList.Find(u => u.Username == newUsername && u.Password == newPassword);
            if (user != null)
            {
                // Login berhasil
                if (user.AccessLevel == "Admin")
                {
                    MessageBox.Show("Login berhasil, selamat datang Admin !!");
                    Form3 form = new Form3();
                    form.Show();
                    this.Hide();

                } else if (user.AccessLevel == "Manager")
                {
                    MessageBox.Show("Login berhasil, selamat datang Manager !!");
                    Form1 form = new Form1();
                    form.Show();
                    this.Hide();

                } else
                {
                    MessageBox.Show("Login berhasil, selamat datang Kasir !!");
                    Form1 form = new Form1();
                    form.Show();
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show("Username atau password Anda salah !!");
            }
        }

        private void clear_Click(object sender, EventArgs e)
        {
            username.Clear();
            password.Clear();
        }
    }
}
